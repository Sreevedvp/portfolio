const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

// Use an installed browser by default. Set PLAYWRIGHT_CHANNEL=chromium for
// Playwright's bundled Chromium. No user browser profile is read or modified.
(async () => {
  const browser = await chromium.launch({ headless: true, channel: process.env.PLAYWRIGHT_CHANNEL || 'chrome' });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(process.env.GALLERY_URL || 'http://127.0.0.1:8095');
    const trigger = page.getByRole('button', { name: 'Try a dialog' });
    await trigger.waitFor();
    assert.equal(await page.locator('style#fast-ui-theme').count(), 1);

    // Field context must update descriptions and validity after mount.
    const email = page.getByLabel('Contact email');
    await page.getByRole('button', { name: 'Save workspace' }).click();
    await page.getByRole('alert').waitFor();
    assert.equal(await email.getAttribute('aria-invalid'), 'true');
    assert.equal(await email.getAttribute('aria-describedby'), 'contact-email-error');
    await email.fill('team@example.com');
    await page.getByRole('alert').waitFor({ state: 'hidden' });
    assert.equal(await email.getAttribute('aria-invalid'), 'false');
    assert.equal(await email.getAttribute('aria-describedby'), null);
    await page.getByRole('button', { name: 'Save workspace' }).click();
    await page.getByRole('status').filter({ hasText: 'Saved 1 times' }).waitFor();
    assert.equal(await page.getByRole('button', { name: 'Saving…' }).isDisabled(), true);

    await trigger.click();
    const dialog = page.locator('#gallery-dialog');
    await dialog.waitFor({ state: 'visible' });
    await page.waitForFunction(() => document.querySelector('#gallery-dialog').contains(document.activeElement));
    assert.equal(await page.locator('html').evaluate(el => getComputedStyle(el).overflow), 'hidden');
    for (let i = 0; i < 12; i++) {
      await page.keyboard.press('Tab');
      assert(await dialog.evaluate(el => el.contains(document.activeElement)), 'Focus escaped modal');
    }
    // Programmatic focus cannot move to background content while modal.
    await page.locator('#workspace-name').evaluate(el => el.focus());
    assert(await dialog.evaluate(el => el.contains(document.activeElement)));
    await dialog.getByRole('button', { name: 'Nested dialog' }).click();
    await page.locator('#nested-dialog').waitFor({ state: 'visible' });
    await page.keyboard.press('Escape');
    await page.locator('#nested-dialog').waitFor({ state: 'hidden' });
    assert(await dialog.isVisible());
    assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), 'Nested dialog');

    const preventDismiss = dialog.getByRole('checkbox');
    await preventDismiss.check();
    await page.keyboard.press('Escape');
    assert(await dialog.isVisible(), 'Pending dialog dismissed');
    assert(await dialog.getByRole('button', { name: 'Close dialog', exact: true }).isDisabled());
    await preventDismiss.uncheck();
    await page.keyboard.press('Escape');
    await dialog.waitFor({ state: 'hidden' });
    assert(await trigger.evaluate(el => el === document.activeElement), 'Trigger focus was not restored');
    assert.notEqual(await page.locator('html').evaluate(el => getComputedStyle(el).overflow), 'hidden');

    // Backdrop dismissal is opt-in and must not fire for an inside click.
    await trigger.click();
    await dialog.getByText('Make room for your ideas', { exact: true }).click();
    assert(await dialog.isVisible());
    await page.mouse.click(4, 4);
    await dialog.waitFor({ state: 'hidden' });

    const before = await trigger.evaluate(el => getComputedStyle(el).backgroundColor);
    await page.getByRole('button', { name: 'Switch theme' }).click();
    await page.waitForFunction(() => getComputedStyle(document.querySelector('.gallery-intro .fui-button')).backgroundColor === 'rgb(49, 94, 66)');
    const after = await trigger.evaluate(el => getComputedStyle(el).backgroundColor);
    assert.notEqual(before, after, 'Theme override did not reach button');
    await trigger.click();
    assert.equal(await dialog.evaluate(el => getComputedStyle(el).backgroundColor), 'rgb(250, 255, 250)');
    await page.keyboard.press('Escape');
    await dialog.waitFor({ state: 'hidden' });
    await page.getByRole('button', { name: 'Switch theme' }).click();

    await page.emulateMedia({ reducedMotion: 'reduce' });
    assert.equal(await page.locator('.fui-spinner').evaluate(el => getComputedStyle(el).animationName), 'none');
    await page.emulateMedia({ reducedMotion: 'no-preference' });

    const out = path.join(__dirname, 'artifacts');
    fs.mkdirSync(out, { recursive: true });
    await page.screenshot({ path: path.join(out, 'gallery-desktop.png'), fullPage: true });
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'Page overflows on mobile');
    await trigger.click();
    await dialog.waitFor({ state: 'visible' });
    const box = await dialog.boundingBox();
    assert(box.x >= 0 && box.x + box.width <= 390, 'Dialog escapes viewport');
    await page.screenshot({ path: path.join(out, 'dialog-mobile.png') });
    await page.keyboard.press('Escape');
    await dialog.waitFor({ state: 'hidden' });
    await page.screenshot({ path: path.join(out, 'gallery-mobile.png'), fullPage: true });
    // Removing an open modal releases its document effects and restores focus.
    await trigger.click();
    await dialog.waitFor({ state: 'visible' });
    await dialog.evaluate(el => el.remove());
    await page.waitForFunction(() => document.activeElement === document.querySelector('.gallery-intro .fui-button'));
    assert.notEqual(await page.locator('html').evaluate(el => getComputedStyle(el).overflow), 'hidden');
    assert.deepEqual(errors, [], 'Browser runtime errors');
    console.log('PASS: fields, native attributes, loading, modal focus/inertness, nested Escape, pending dismissal, backdrop, themes, reduced motion, mobile layout, modal removal cleanup.');
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
