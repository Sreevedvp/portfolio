const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

// UI regression fixtures only. All /api requests are intercepted; no real
// account, story, or FastMedium database is read or changed by this test.
(async () => {
  const browser = await chromium.launch({ headless: true, channel: process.env.PLAYWRIGHT_CHANNEL || 'chrome' });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const base = process.env.FASTMEDIUM_URL || 'http://127.0.0.1:8096';
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    const user = { id: 'fixture-user', username: 'writer', display_name: 'Test Writer', email: 'writer@example.com', bio: '', avatar_url: null, created_at: '2026-09-27' };
    const post = { id: 'fixture-post', title: 'A sample story', slug: 'sample', excerpt: 'A browser fixture', author_username: 'writer', author_display_name: 'Test Writer', published_at: null, reading_time_minutes: 2 };
    let authenticated = false;
    let deleted = false;
    let attempts = 0;
    let credentials;
    await page.route('**/api/**', async route => {
      const request = route.request();
      const url = new URL(request.url());
      let body = null, status = 200;
      if (url.pathname === '/api/auth/me') body = authenticated ? user : null;
      else if (url.pathname === '/api/auth/login') {
        credentials = request.postDataJSON(); authenticated = true; body = user;
      } else if (url.pathname === '/api/posts/mine') body = deleted ? [] : [post];
      else if (url.pathname === '/api/posts/fixture-post' && request.method() === 'DELETE') {
        attempts++;
        if (attempts === 1) { status = 500; body = { error: 'Please try again' }; }
        else { deleted = true; }
      } else if (url.pathname === '/api/posts' || url.pathname === '/api/publications') body = [];
      await route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
    });
    await page.goto(`${base}/login`);
    await page.getByLabel('Email', { exact: true }).fill('writer@example.com');
    await page.getByLabel('Password', { exact: true }).fill('sample-password');
    const out = path.join(__dirname, 'artifacts');
    fs.mkdirSync(out, { recursive: true });
    await page.screenshot({ path: path.join(out, 'fastmedium-login.png'), fullPage: true });
    await page.getByRole('button', { name: 'Sign In', exact: true }).click();
    await page.waitForURL(`${base}/`);
    assert.deepEqual(credentials, { email: 'writer@example.com', password: 'sample-password' });

    await page.goto(`${base}/dashboard`);
    const remove = page.getByRole('button', { name: 'Delete', exact: true });
    await remove.click();
    const dialog = page.getByRole('dialog', { name: 'Delete this story?' });
    await dialog.waitFor();
    await dialog.getByRole('button', { name: 'Keep story' }).click();
    await dialog.waitFor({ state: 'hidden' });
    assert.equal(attempts, 0, 'Cancel performed a mutation');
    assert(await remove.evaluate(el => document.activeElement === el));
    await remove.click();
    await dialog.getByRole('button', { name: 'Confirm delete' }).click();
    await dialog.getByRole('alert').filter({ hasText: 'Please try again' }).waitFor();
    assert(await dialog.isVisible(), 'Failed delete lost confirmation context');
    await dialog.getByRole('button', { name: 'Confirm delete' }).click();
    await dialog.waitFor({ state: 'hidden' });
    await page.getByRole('heading', { name: 'No stories yet' }).waitFor();
    assert.equal(attempts, 2);

    await page.goto(`${base}/register`);
    await page.getByLabel('Username', { exact: true }).fill('new-writer');
    await page.getByLabel('Display Name', { exact: true }).fill('New Writer');
    await page.getByLabel('Email', { exact: true }).fill('new@example.com');
    await page.getByLabel('Password', { exact: true }).fill('password-one');
    await page.getByLabel('Confirm Password', { exact: true }).fill('password-two');
    await page.getByRole('button', { name: 'Create Account' }).click();
    await page.getByRole('alert').filter({ hasText: 'Passwords do not match' }).waitFor();
    assert(await page.getByRole('button', { name: 'Create Account' }).isEnabled());

    await page.goto(`${base}/preview`);
    await page.getByRole('table', { name: 'A quieter writing practice' }).waitFor();
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(`${base}/login`);
    await page.getByLabel('Email', { exact: true }).waitFor();
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({ path: path.join(out, 'fastmedium-login-mobile.png'), fullPage: true });
    assert.deepEqual(errors, []);
    console.log('PASS: FastMedium login payload/navigation, registration validation, table semantics, cancel/focus restoration, failed-delete retry, successful deletion, mobile login. API fixtures only.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
