use dioxus::prelude::*;
use fast_ui::*;

fn render(app: fn() -> Element) -> String {
    let mut dom = VirtualDom::new(app);
    dom.rebuild_in_place();
    dioxus_ssr::render(&dom)
}

#[test]
fn buttons_are_safe_inside_forms_and_loading_cannot_be_overridden() {
    let html = render(|| {
        rsx! {
            Button { loading: true, "aria-busy": "false", "Save" }
        }
    });
    assert!(html.contains("type=\"button\""), "{html}");
    assert!(html.contains("disabled"), "{html}");
    assert!(html.contains("aria-busy=\"true\""), "{html}");
    assert!(!html.contains("aria-busy=\"false\""), "{html}");
}

#[test]
fn field_connects_label_hint_and_error_without_losing_native_attributes() {
    let html = render(|| {
        rsx! {
            Field { id: "email", label: "Email", hint: "Use a work address", error: "Invalid address",
                Input { value: "invalid", on_value_change: |_| {},
                    name: "contact", required: true, autocomplete: "email", described_by: "external-hint",
                    "aria-invalid": "false"
                }
            }
        }
    });
    for expected in [
        "for=\"email\"",
        "id=\"email\"",
        "name=\"contact\"",
        "required",
        "autocomplete=\"email\"",
        "aria-invalid=\"true\"",
        "aria-describedby=\"external-hint email-hint email-error\"",
        "role=\"alert\"",
    ] {
        assert!(html.contains(expected), "Missing {expected}: {html}");
    }
}

#[test]
fn standalone_input_does_not_reference_missing_descriptions() {
    let html = render(|| {
        rsx! {
            Input { id: "search", value: "", on_value_change: |_| {}, "aria-label": "Search" }
        }
    });
    assert!(html.contains("aria-label=\"Search\""));
    assert!(!html.contains("aria-describedby"), "{html}");
}

#[test]
fn table_preserves_native_semantics_and_escapes_consumer_text() {
    let html = render(|| {
        rsx! {
            Table { caption: "Inventory",
                thead { tr { th { scope: "col", "Item" } } }
                tbody { tr { td { "<script>untrusted</script>" } } }
            }
        }
    });
    for expected in [
        "<table",
        "<caption>Inventory</caption>",
        "scope=\"col\"",
        "&#60;script&#62;",
        "role=\"region\"",
    ] {
        assert!(html.contains(expected), "Missing {expected}: {html}");
    }
    assert!(!html.contains("<script>"));
}

#[test]
fn dialog_server_markup_is_deterministic_and_does_not_open_before_mount() {
    fn element() -> Element {
        rsx! { Dialog { id: "confirm", title: "Confirm", description: "Review the change", open: true,
            on_open_change: |_| {}, Button { "Cancel" }
        } }
    }
    let first = render(element);
    let second = render(element);
    assert_eq!(first, second);
    assert!(first.contains("aria-labelledby=\"confirm-title\""));
    assert!(first.contains("aria-describedby=\"confirm-description\""));
    assert!(!first.contains(" open="));
}
