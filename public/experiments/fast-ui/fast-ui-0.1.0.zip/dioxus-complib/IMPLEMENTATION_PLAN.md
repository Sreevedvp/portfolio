# Reusable Rust UI library implementation plan

Status: initial slice implemented in this standalone `dioxus-complib` project: theme, Button, Field/Input,
semantic Table, and Dialog; standalone gallery and FastMedium adoption included.
The broader catalog and compatibility milestones below remain the roadmap.
Working name: `fast-ui` (package/repository availability not checked).

## 1. Outcome and scope

Create a reusable component system for Dioxus applications with FastMedium's existing visual language. Developers can install individual components as editable Rust source, like shadcn, or later consume the same components through a Cargo library.

The two supplied images define component coverage: forms, tables, dialogs, drawers, menus, feedback, and related controls. Their page layouts, cream backgrounds, serif typography, telemetry labels, and sample infrastructure data are not requirements. The user's request takes precedence over text appearing inside those images.

Initial target: Dioxus 0.7.10 browser applications. Keep the architecture ready for desktop WebViews and SSR, but advertise those targets only after they pass their own checks. Other Rust UI frameworks can reuse the CSS tokens and suitable pure Rust logic; Dioxus components cannot directly render in Leptos, Yew, egui, or arbitrary Rust programs. Those require separate adapters.

## 2. Findings from FastMedium

| Existing source | Finding | Extraction decision |
|---|---|---|
| `Cargo.toml`, `Cargo.lock` | Dioxus 0.7.10; web frontend and separate Axum backend | Start with that exact version as the tested baseline; no backend dependency in UI |
| `assets/main.css:17–27` | Later CSS rules override earlier styling | Extract the effective cascade, not just the first declarations |
| `assets/main.css:18–19` | Blush surfaces, coral accent, black borders, Geist Mono headings, Poppins body | Create a named FastMedium theme |
| `src/app.rs` | One stylesheet loaded at the root; authentication and search contexts | Mount UI styles once; keep application contexts out of the library |
| `src/components/post_card.rs` | Card includes application routes and author/story fields | Keep `PostCard` in the application; compose it from generic UI parts |
| `src/pages/login.rs`, `register.rs`, `dashboard.rs` | Repeated fields, buttons, status/error UI and actions | First migration targets |
| `src/pages/reference.rs` | Semantic HTML table already present | First low-risk table integration |
| `scripts/verify.sh` | Existing backend, API, and WASM verification | Preserve these checks during adoption |

The CSS also has misleading legacy names (`--green` is coral; `--serif` is Geist Mono), hardcoded colors, global selectors, and an undefined `--text-secondary` reference. Resolve those during extraction rather than publishing them as the new API.

## 3. What “version independent” can mean

Full compatibility with all future Dioxus versions is not a realistic guarantee. Component APIs expose Dioxus types such as `Element`, events, and reactive state, so breaking framework changes require adapter updates.

Provide independence in three useful ways:

1. **Theme independence:** plain CSS custom properties and token data have no Dioxus dependency.
2. **Application ownership:** installed components live in the consumer's source tree and can be edited or migrated without waiting for a library release. Copied source can still depend on versioned primitives; ownership does not remove that dependency.
3. **Explicit compatibility:** each registry release declares the Dioxus range, primitive revision, renderer targets, and minimum Rust version actually tested. Future breaking Dioxus lines receive separate adapter tracks while reusing tokens and pure Rust behavior.

Start with a minimum Dioxus version of 0.7.10. A requirement of `0.7.10` permits compatible 0.7 patch updates, not 0.8. Test the minimum and the newest resolved 0.7 patch before widening the documented support range. Do not use `*` or a broad cross-breaking-version range to claim independence. Cargo's compatibility rules are documented in the [Cargo Book](https://doc.rust-lang.org/cargo/reference/specifying-dependencies.html).

Version the library separately from Dioxus. During `0.x`, document breaking changes in minor library releases; after `1.0`, use major releases for breaking public APIs. Track Rust props, CSS tokens, styling hooks, and registry structure as public contracts. Retain the previous tested framework track when introducing a new one and publish a migration guide.

## 4. Architecture and distribution

Use the existing Dioxus component registry protocol as the primary distribution mechanism. [Dioxus Components](https://github.com/DioxusLabs/dioxus-components) already combines copyable styled components with unstyled primitives. Locally, `dx 0.7.10` confirms custom registry installation through `--git`, `--rev`, `--path`, `--module-path`, and `--global-assets-path`.

Prefer adapting compatible upstream primitives for focus, keyboard navigation, and overlays. Audit their behavior, features, licenses, and Dioxus compatibility at a pinned revision before selecting them. Their existence does not establish that every component or platform meets this project's requirements.

Build four layers:

| Layer | Responsibility | Dependencies |
|---|---|---|
| Tokens/theme | Colors, typography, spacing, borders, motion, component CSS | CSS and optional token JSON only |
| Behavior | Table sorting/selection, pagination bounds, other substantial reusable logic | Pure Rust; no Dioxus types |
| Dioxus adapter | RSX, event/state bindings, accessibility, platform integration | Supported Dioxus line and audited primitives |
| Recipes/examples | Settings form, selectable table, confirmation workflow | Public components only; application-shaped examples |

Extract pure Rust logic only where it is useful and testable. Do not build a universal framework abstraction for simple controls. Browser positioning and focus management remain renderer-specific.

Proposed standalone repository structure:

```text
fast-ui/
  Cargo.toml                    # workspace
  component.json                # registry members
  registry/
    button/{component.json,mod.rs,style.css}
    field/{component.json,mod.rs,style.css}
    table/{component.json,mod.rs,style.css}
    dialog/{component.json,mod.rs,style.css}
    ...
  themes/
    tokens.json
    fastmedium.css
  crates/
    fast-ui-core/               # only framework-free behavior
    fast-ui-dioxus/             # optional generated Cargo facade
  examples/
    gallery/                   # every component and state
    consumer-web/              # independent app with no FastMedium imports
    consumer-ssr/              # compatibility fixture, later milestone
    consumer-desktop/          # WebView fixture, later milestone
  tests/
    browser/
    registry/
  docs/
    compatibility.md
    migration.md
    component-contracts.md
```

Develop and validate in a standalone workspace, with FastMedium as an external consumer. A temporary local dependency is acceptable while developing. Publishing and hosting are later implementation steps, not actions performed by this plan.

Registry source is canonical. If the Cargo facade is introduced, generate its source/assets from a fixed registry revision and check for drift in CI; never maintain two manual component implementations. Validate packaged asset paths in an external consumer before offering crate mode.

Use `dx components schema` to validate manifests. Compatibility metadata and installed-source hashes belong in a separate `fast-ui.lock.json`; the current component schema does not accept arbitrary extra fields. Keep the initial install workflow manual where necessary rather than building a competing CLI.

## 5. FastMedium theme contract

| New token | Initial value | Purpose |
|---|---|---|
| `--fui-background` | `#fbe4e4` | Main blush canvas |
| `--fui-surface` | `#fff3f0` | Raised/input-adjacent surface |
| `--fui-control-background` | `#fff2ee` | Current form field surface |
| `--fui-surface-muted` | `#f5d4d2` | Subtle hover/section surface |
| `--fui-foreground` | `#111111` | Main text |
| `--fui-muted-foreground` | `#755b58` | Supporting text |
| `--fui-accent` | `#d34a45` | Coral brand accent |
| `--fui-accent-hover` | `#ae3b36` | Current stronger hover accent |
| `--fui-border` | `#d5aaa6` | Quiet dividers |
| `--fui-border-strong` | `#111111` | Controls and outlined surfaces |
| `--fui-font-body` | `Poppins, sans-serif` | Body and controls |
| `--fui-font-heading` | `Geist Mono, monospace` | Headings |
| `--fui-font-mono` | `Geist Mono, monospace` | Code and metadata |
| `--fui-radius-control` | `3px` | Inputs/buttons |
| `--fui-radius-panel` | `0px` | Flat outlined panels |

Add explicit foreground-on-accent, success, warning, info, destructive, focus-ring, overlay, shadow, spacing, size, density, and motion tokens. Status colors must be distinct from the brand accent and reinforced with text/icons. These new values need visual and contrast validation rather than being guessed from the screenshots.

Preserve the blush/coral/black identity while allowing accessible adjustments to color pairs. In particular, validate small text on coral buttons before accepting the existing pairing. Provide comfortable and compact density; do not inherit screenshot-sized microtext as the default.

Use `.fui-*` component classes and a scoped theme root such as `[data-fui-theme="fastmedium"]`. Ship no mandatory `body`, `h1`, `button`, or `input` resets. Keep a separate optional page reset. Controls set the styles they need inside their own scope. Supply styles for overlays in the same theme scope, including when portalled, and test coexistence with FastMedium's existing selectors.

Fonts are configurable and not silently fetched from Google Fonts. Document optional local font assets and licensing, with system fallbacks. FastMedium's existing font import can remain an application decision during migration. Reduced-motion behavior is part of the theme contract; dark mode is a later separately verified theme.

## 6. Component coverage and release order

| Delivery | Components | Required behavior |
|---|---|---|
| Foundation | Theme/styles, Button, IconButton, Link styling, Card, Separator, Badge, Avatar, Text/Heading | Variants, sizes, disabled/loading states, semantic elements, configurable content |
| Form basics | Field, Label, Hint, Error, Input, Textarea, NativeSelect, Checkbox, RadioGroup, Switch | Labels, validation wiring, controlled values, disabled/read-only/required states |
| Tables | Table, Caption, Head, Body, Row, HeaderCell, Cell, Pagination | Semantic markup, responsive overflow, empty/loading/error states |
| Popups and feedback | Dialog, AlertDialog, Popover, Tooltip, DropdownMenu, Alert, Toast, Spinner, Skeleton, Progress | Defined keyboard/focus/dismissal behavior and announcement semantics |
| Advanced interaction | Drawer/Sheet, ContextMenu, Tabs, Accordion/Collapsible, ToggleGroup, Slider, NumberInput/Stepper | Composable parts, appropriate keyboard operation, bounds and selection state |
| Advanced forms | Custom Select, Combobox, TagInput, DatePicker and DateRangePicker | Search, clear/empty states, localized dates, keyboard selection and validation |
| Composition | Sidebar/Nav items, Breadcrumbs, Toolbar, CodeBlock, DataTable recipes | Arbitrary children/data/actions, router-independent defaults |

The first usable release includes foundation, form basics, semantic tables, dialogs/popovers, and basic feedback. The extended release completes the pictured interaction inventory. Rich code editing, charts, and virtualization are separate optional integrations after measured need; the screenshots' code boxes and sparkline do not imply building an IDE or charting engine.

“Popup” is represented by specific components with distinct semantics. Dialogs block interaction when modal; popovers hold anchored content; menus provide actions; tooltips explain a trigger. Do not merge these into one configurable catch-all component.

## 7. Generic API rules

- Accept owned props and meaningful enums (`Variant`, `Size`, `Status`), with `Clone`/`PartialEq` where required by Dioxus. Use children for content, not application-specific fields.
- Use Dioxus 0.7 `#[component]`, `Element`, `use_signal`, and `ReadOnlySignal` where reactive props are useful; no legacy `cx`, `Scope`, or `use_state`. Follow the [0.7 component documentation](https://dioxuslabs.com/learn/0.7/essentials/ui/components/).
- Prefer a controlled value and change callback for stateful controls; optionally support a default value for uncontrolled use. Define one source of truth and do not switch modes during a mounted lifetime.
- Expose `class`, `id`, appropriate `aria-*`/`data-*` attributes, and element-specific event hooks. Specify attribute precedence; customization must not accidentally remove required accessibility behavior.
- Separate action buttons from links. Router integration is optional and must not require FastMedium's `Route`. Native links accept URLs; apps can supply router-aware children to composition slots.
- Keep auth, database access, API calls, domain models, fetching, and mutation decisions in consuming applications. No direct `Post`, `User`, or publication types in the library.
- Default buttons to `type="button"`; allow explicit submit/reset. Preserve browser form behavior and autocomplete through input props.
- Expose compound parts where needed: dialog title/description/actions, card header/body/footer, and table sections. Start with straightforward composition rather than deeply nested configuration objects.

Proposed consumer shape (illustrative API, not implemented or compile-verified):

```rust
use dioxus::prelude::*;
use crate::ui::{Button, ButtonVariant, Dialog, DialogTitle};

#[component]
fn Example() -> Element {
    let mut open = use_signal(|| false);
    rsx! {
        Button { onclick: move |_| open.set(true), "Open settings" }
        Dialog { open: open(), on_open_change: move |next| open.set(next),
            DialogTitle { "Settings" }
            p { "Place any application content here." }
            Button {
                variant: ButtonVariant::Secondary,
                onclick: move |_| open.set(false),
                "Close"
            }
        }
    }
}
```

The dialog associates its title through internal context/IDs. The application owns the open state. Content and callbacks have no knowledge of FastMedium. Loading the theme once at the app root is separate from this component.

## 8. Table and overlay implementation decisions

Build semantic table parts first. Add a `DataTable<T>` recipe only after basic tables work, with stable row keys, typed column access/rendering, optional selection, and explicit sorting/filtering/pagination state. Never key rows by array position. For remote data, emit state-change callbacks and let the app fetch; do not pretend the loaded page is the entire dataset. Include total-row/page information, custom cell rendering, selection scope, sortable-header `aria-sort`, and keyboard-accessible actions. Preserve selection across reordering by identity. Virtualization is optional later work.

Prefer audited primitives over hand-written focus traps. Every modal needs an accessible name, appropriate initial focus, focus containment, focus restoration, background inertness, scroll-lock cleanup, and predictable Escape/backdrop behavior. Define which dismissal methods are enabled for pending/destructive workflows. Escape closes only the topmost dismissible surface. Test nested overlays and unmounting. Follow the [WAI-ARIA modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/).

Anchored overlays need collision handling, scrolling/resizing updates, clipping avoidance, stacking rules, and theme inheritance. Tooltips must work with keyboard focus and not contain interactive controls. Toasts need a live region, configurable duration, pause behavior, and a persistent alternative for important messages.

Defer DOM measurement, browser storage, and focus work until client effects. Keep the initial server/client tree and IDs deterministic. SSR fixtures must prove hydration behavior; FastMedium itself is currently client-rendered and does not need conversion to fullstack. [Dioxus 0.7 documentation](https://dioxuslabs.com/learn/0.7/) is the framework reference.

## 9. Installation, updates, and reuse

Use an immutable registry revision for repeatable installations. Example local-development command, supported by the installed CLI:

```sh
dx components add button table dialog \
  --path ../fast-ui \
  --module-path src/ui \
  --global-assets-path assets
```

This assumes the proposed registry exists at that path. For a remote release, replace `--path` with `--git <actual-repository-url> --rev <immutable-commit>`. Confirm multi-component dependencies, module exports, and generated asset paths in the registry fixture before publishing the instructions as runnable installation documentation.

Mount the copied theme asset once, using Dioxus's asset system and `document::Stylesheet`; verify the generated location rather than hardcoding an assumed output path. The [0.7 asset documentation](https://dioxuslabs.com/learn/0.7/essentials/ui/assets/) describes bundling.

Record the registry revision, selected components, theme version, framework track, dependency versions, and baseline file hashes. Updates install into a temporary fixture first, then produce a diff against locally customized files. Avoid `--force` on a working consumer. Preserve local edits and require explicit conflict resolution. `dx components update` is described by the installed CLI as updating a registry; do not assume it safely merges installed source. Automate merging only if later investigation establishes a reliable mechanism.

Crate mode is a later convenience: feature-gate optional components/integrations, let the application select its renderer, and avoid enabling router/server/network stacks by default. Verify source mode and crate mode against the same behavior fixtures. Preserve license notices for copied upstream code and assets.

## 10. Delivery milestones and acceptance gates

| Phase | Work | Exit condition |
|---|---|---|
| 0. Baseline and compatibility | Capture FastMedium screenshots/computed styles; audit upstream primitives; freeze tested dependencies; inventory components | Theme baseline and compatibility decision recorded, one primitive spike builds on 0.7.10 |
| 1. Theme and registry | Create standalone workspace, tokens, scoped CSS, manifests; implement Button/Card/Field/Input | Components install into a blank consumer, render correctly, and do not change unrelated host elements |
| 2. First complete workflow | Semantic Table/Pagination, Dialog/AlertDialog, Popover, basic feedback | A selectable table with row actions and confirmation works using only generic public APIs |
| 3. FastMedium adoption | Migrate login/register, reference table, dashboard confirmation/status, then shared buttons/cards | Existing app flows and visual identity retained; backend verification passes |
| 4. Extended inventory | Menus, drawers, tabs, advanced inputs, date controls, remaining feedback and composition | Each planned component has examples, documented props, interaction checks, and responsive states |
| 5. Cross-project proof | Independent consumer with unrelated data; alternate theme; desktop/SSR fixtures if advertised | Reuse succeeds without FastMedium imports, global style leaks, or unverified target claims |
| 6. Distribution hardening | Update/diff workflow, optional generated crate facade, packaging, compatibility and migration docs | Clean installation and upgrade rehearsal pass; release artifacts are ready to publish |

Critical order: theme/registry → foundational controls → overlay behavior and tables → application migration → extended coverage → broader compatibility. Finish and validate each slice before expanding the catalog.

FastMedium migration is incremental. Add `src/ui` and namespaced assets first; wire the theme at `src/app.rs`; retain domain components and page layout CSS. Replace duplicated markup page by page, then remove only selectors proven unused. Keep existing persistence, API clients, routes, and application state behavior intact. A future generic Sidebar does not force adoption of either screenshot's shell.

## 11. Verification and completion criteria

- **Rust behavior:** meaningful tests for table identity/selection, sorting/pagination boundaries, value bounds, and controlled-state transitions; compile fixtures for public prop contracts.
- **Browser interaction:** real keyboard/pointer tests for forms, dialog focus restoration, nested overlays, menus, tabs, popover positioning, loading/error states, and toast announcements.
- **Accessibility:** automated checks plus manual keyboard and screen-reader checks; verify names/descriptions, contrast, reduced motion, zoom, and touch target usability.
- **Visual checks:** gallery screenshots at narrow/mobile, tablet, and desktop widths; FastMedium before/after comparisons; long content, empty content, disabled states, and alternate theme.
- **Isolation:** gallery and independent consumer build without FastMedium backend/models. Library styles coexist with a host stylesheet. One theme instance and correctly styled portal content.
- **Compatibility:** separate jobs for baseline and newest supported 0.7 patch, declared minimum Rust and stable, browser WASM, and each advertised desktop/SSR target. Lock fixture dependencies for reproducibility; never count host-only `cargo check` as a browser test.
- **Distribution:** clean registry install, dependency resolution, selective install, reinstall/conflict behavior, copied asset delivery, and source hashes. If crate mode ships, verify `cargo package` and consume the packaged result from outside the workspace.
- **FastMedium regression:** run `./scripts/verify.sh`, then exercise sign-in, forms, story actions, and navigation in the browser after migration.

Complete when the agreed component inventory is available, FastMedium uses the first shared components, a second unrelated example application successfully reuses them, and installation/compatibility/customization are documented and verified. The implementation must demonstrate reuse; copying existing FastMedium page components into a crate is insufficient.

## 12. Immediate implementation slice

Start with **FastMedium tokens + Button + Field/Input + semantic Table + Dialog**, distributed through a local Dioxus registry and demonstrated in a standalone gallery. Validate the foundation against FastMedium and one blank consumer before building the larger catalog or a custom installer.

This document records the original plan. Consult `README.md` for the
implemented API, tested install command, current verification, and remaining
scope. In particular, install the `theme` registry component explicitly with
dx 0.7.10; the conceptual DialogTitle example above is not the current API.
