# Fast UI

Reusable Dioxus components with FastMedium's blush surfaces, coral accents,
black borders, and configurable Poppins/Geist Mono typography. The library has
no FastMedium routes, models, API calls, or authentication dependencies.

This is the first implementation slice: **Theme, Button, Field/Input, Table,
and Dialog**. There is a standalone gallery, a real copied-source installation
check, and FastMedium integrations. It is not the complete component catalog.

## Use as a Rust library

From another Dioxus 0.7.10 project, point to this directory:

```toml
[dependencies]
dioxus = { version = "0.7.10", features = ["web"] }
fast-ui = { path = "../dioxus-complib" }
```

Adjust the path for your checkout. This package is not published on crates.io.
The UI crate does not choose a renderer or enable the router. An application
selects those features on its own Dioxus dependency.

```rust
use dioxus::prelude::*;
use fast_ui::{Button, Field, Input, Theme, ThemeStyles};

#[component]
fn App() -> Element {
    let mut name = use_signal(String::new);
    rsx! {
        ThemeStyles {}
        Theme {
            Field { id: "name", label: "Name", hint: "How should we address you?",
                Input { value: name(), on_value_change: move |value| name.set(value) }
            }
            Button { onclick: move |_| name.set(String::new()), "Clear" }
        }
    }
}
```

Mount `ThemeStyles` once. Wrap your components in `Theme`; it adds a normal
`div`, so account for that element in flex/grid layouts. Fonts are not fetched
automatically. Load your own fonts or use the supplied system fallbacks.

## Install editable source, like shadcn

In an existing Dioxus 0.7.10 application, run:

```sh
dx components add theme button field table dialog \
  --path /absolute/path/to/dioxus-complib \
  --module-path src/ui
```

Then declare `mod ui;` in your app root and import, for example,
`ui::button::Button` and `ui::theme::{Theme, ThemeStyles}`. Select only the
components you need; install `theme` once. An additional component can be added
later without reinstalling it:

```sh
dx components add table --path /absolute/path/to/dioxus-complib --module-path src/ui
```

Each component is self-contained. CSS ships with the theme module; Dialog's
small browser adapter ships alongside its Rust source. There are no absolute
asset paths, hidden imports from the FastMedium application, or runtime network
requests. Registry installation intentionally does not edit `Cargo.toml`:
the host must already supply Dioxus 0.7.10 with `lib` and its renderer/launch
features (the default Dioxus features plus `web` satisfy this).

**CLI compatibility detail:** in dx 0.7.10, string `componentDependencies`
refer to the upstream registry, not a sibling in a local custom registry.
Install `theme` explicitly. The local install is tested with the actual CLI.

You own copied files. Do not use `--force` to update customized components.
Install a new version into a temporary app, compare files, and merge deliberately.
`dx components update` updates the registry cache; it is not a local-source merge
tool. Record the source revision and your baseline hashes in project history.
The regression script demonstrates a baseline `fast-ui.lock.json` file; automatic
consumer upgrade/merge tooling remains a later milestone.

## Component contracts

| Component | Contract |
|---|---|
| Theme | Scoped `--fui-*` variables, optional compact density, `class` and global attributes |
| Button | Primary/secondary/ghost/destructive; three sizes; disabled/loading; defaults to `type="button"`; explicit `ButtonType::Submit` for forms |
| Field | One control, stable unique ID, label, optional hint/error; Input automatically inherits accessibility references |
| Input | Controlled `value` and `on_value_change`; forwards native input attributes; standalone use requires a label/accessible name |
| Table | Required visible caption; native thead/tbody/tr/th/td children; keyboard-scrollable horizontal overflow |
| Dialog | Controlled `open` and `on_open_change`; required title and stable unique ID; optional description; configurable dismissal |

Forwarded attributes cannot replace component-owned class/type/value/validity
or button disabled/loading behavior. Use explicit props for those. Other native
attributes, ARIA labels, data attributes, and events remain available on Button,
Input, Table, and Theme. Combine `class` with your own CSS for customization.
Keep an Input ID equal to its enclosing Field ID; labels and descriptions are
derived from that Field. Field supports native controls as children, but those
must wire their own IDs and validity attributes.

Table intentionally accepts semantic HTML children rather than wrapping every
HTML element. Apps own row keys, formatting, fetching, sorting, and pagination.
A typed DataTable recipe will be a later layer; no domain model is required here.

Dialog uses native `showModal()` for inertness and top-layer rendering, with a
small adapter for controlled dismissal and endpoint Tab wrapping. It stays inside
the theme DOM subtree. Escape requests closure; the parent updates `open`.
`dismissible: false` disables Close/Escape/backdrop requests during pending work.
Backdrop dismissal defaults to false. The close button receives initial focus;
mark a child with `data-fui-autofocus` for another initial focus target. Avoid
`form method="dialog"`, which bypasses controlled dismissal. Keep dialog IDs
stable throughout a mount and unique across the document. Test focus recovery
in application workflows that remove the original trigger.

## Customize the theme

```rust
Theme {
    class: "my-theme",
    compact: true,
    Button { "A different project" }
}
```

```css
.fui-theme.my-theme {
  --fui-background: #eef3ee;
  --fui-surface: #fafffa;
  --fui-action: #315e42;
  --fui-action-hover: #244731;
  --fui-radius-control: 8px;
}
```

The full token list is in `registry/theme/theme.css`. Theme does not force a
page background; apply `background: var(--fui-background)` in your app layout.
No mandatory global reset is shipped. The only document-level style locks
scrolling while a `.fui-dialog` is open. Native modal placement preserves theme
inheritance. The gallery includes an alternate theme to demonstrate reuse.

Primary action backgrounds use `#ae3b36` (FastMedium's darker coral) to give
small `#fff3f0` labels adequate contrast. Decorative coral remains `#d34a45`.

## Run the gallery

```sh
cd examples/gallery
dx serve --web --port 8095 --open false
```

The gallery is an unrelated equipment/workspace example with no FastMedium
imports. It exercises forms, validation, tables, dialogs, nested dialogs,
pending dismissal, density, and theme overrides.

## Verify

From this directory:

```sh
bash scripts/verify.sh
```

The registry check needs the WASM target, Dioxus CLI 0.7.10, and cached Cargo
dependencies; it deliberately runs offline. It creates a temporary standalone
consumer, verifies source/asset copies, verifies custom source is not overwritten,
and compiles it to WASM. Its temporary directory is removed on exit.

With the gallery running and Playwright available to Node:

```sh
node tests/browser/verify.cjs
```

The browser test uses installed Google Chrome by default. Set
`PLAYWRIGHT_CHANNEL=chromium` to use Playwright's installed Chromium.
`GALLERY_URL` can override the local URL. Screenshots go to the ignored
`tests/browser/artifacts/` directory. Browser tests cover dynamic descriptions,
modal focus/inertness, nested Escape, pending actions, backdrop dismissal, theme
inheritance, reduced motion, and mobile overflow.

To check FastMedium's migrated pages with its frontend running on port 8096:

```sh
node tests/browser/fastmedium.cjs
```

This test intercepts every API request with fixtures. It verifies form payloads,
validation, navigation, table accessibility, and delete confirmation/retry without
touching real accounts or stories. `FASTMEDIUM_URL` overrides the frontend URL.
Run FastMedium's existing `scripts/verify.sh` separately for real API regression
coverage against its temporary database.

Verification performed for this slice: five Rust rendering/contract tests,
WASM builds for FastMedium and the gallery, clean independent source installation,
crate packaging verification, Chrome interaction/mobile checks, FastMedium UI
fixture checks, and the existing backend/API regression suite. CI also checks
the standalone workspace's formatting, Rust tests, WASM build, and package.

## Compatibility and remaining work

The current baseline is **Dioxus 0.7.10, browser DOM**. Crate dependencies allow
compatible 0.7 patch updates; that is not a promise of compatibility with every
future patch or with 0.8. CSS can be used outside Dioxus; Rust components cannot
be directly mounted in other Rust UI frameworks. No unnecessary framework-free
behavior crate exists yet because this slice has no substantial shared algorithm.

Server markup contracts have tests, but SSR hydration, desktop/mobile WebViews,
screen-reader audits, and non-Chromium browser verification are not yet certified.
Dialogs open after client mount; their initial server markup remains closed.
Popover/menu/tooltip, drawer, toast, richer form controls, typed DataTable,
automatic upgrade tooling, and a remote published registry are later milestones
from `IMPLEMENTATION_PLAN.md`.

Both crate and source mode read the same `registry/` files. This standalone
workspace can be moved into its own repository without copying FastMedium code.


## Standalone project and portfolio documentation

The canonical library lives in the `dioxus-complib` Codex project, separate from
FastMedium. FastMedium consumes an editable registry snapshot in `src/ui`, so
its builds do not depend on a checkout elsewhere on the developer's machine.
This workspace owns the library, examples, tests, and CI.

`examples/playground` is the compact, real Dioxus/WASM demo embedded in the
portfolio's separate **Experiments** documentation section. To regenerate the
portfolio's static preview and downloadable source archive, run:

```sh
python3 scripts/export_portfolio.py /path/to/portfolio/public/experiments/fast-ui
```

The exporter builds a release WASM app, copies its self-contained assets, and
creates `fast-ui-0.1.0.zip` with source hashes in `release.json`. Build caches,
Git metadata, local environment files, and test screenshots are excluded.
The source archive extracts to `dioxus-complib/`. Nothing is deployed by this
command. The embedded demo expects the portfolio to be hosted at the domain
root under `/experiments/fast-ui/playground/`.
