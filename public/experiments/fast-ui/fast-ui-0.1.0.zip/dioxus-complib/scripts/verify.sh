#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
cargo fmt --all --check
cargo test --locked -p fast-ui
cargo check --locked --workspace --target wasm32-unknown-unknown
python3 scripts/check_registry.py

