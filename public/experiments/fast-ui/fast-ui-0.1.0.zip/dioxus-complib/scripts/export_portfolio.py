#!/usr/bin/env python3
"""Build and export the real Rust playground and a source archive.

Usage: python3 scripts/export_portfolio.py /path/to/portfolio/public/experiments/fast-ui
No deployment is performed. Install dx 0.7.10 and the WASM target first.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('output', type=Path)
parser.add_argument('--offline', action='store_true')
args = parser.parse_args()
command = ['dx', 'build', '--web', '--release', '--base-path', '/experiments/fast-ui/playground', '--debug-symbols', 'false']
if args.offline:
    command.append('--offline')
env = dict(os.environ, CARGO_TARGET_DIR=str(root / 'target'))
subprocess.run(command, cwd=root / 'examples/playground', env=env, check=True)
build = root / 'target/dx/fast-ui-playground/release/web/public'
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
playground = output / 'playground'
# Only replace an earlier exporter-owned playground, never unrelated output.
if playground.exists():
    marker = output / 'release.json'
    if not marker.exists() or json.loads(marker.read_text()).get('library') != 'fast-ui':
        raise SystemExit('Refusing to replace an unrecognized playground directory')
    shutil.rmtree(playground)
shutil.copytree(build, playground)

archive = output / 'fast-ui-0.1.0.zip'
files = {}
excluded = {'.git', 'target', 'artifacts', '__pycache__', 'node_modules'}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if not path.is_file() or excluded.intersection(relative.parts) or path.name == '.DS_Store' or path.name.startswith('.env'):
            continue
        data = path.read_bytes()
        info = zipfile.ZipInfo('dioxus-complib/' + relative.as_posix())
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o100644 << 16)
        bundle.writestr(info, data)
        files[relative.as_posix()] = hashlib.sha256(data).hexdigest()
metadata = {'library': 'fast-ui', 'version': '0.1.0', 'status': 'experimental',
            'dioxus_tested': '0.7.10', 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files': files}
(output / 'release.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(f'Exported {len(files)} source files and the compiled playground to {output}')
