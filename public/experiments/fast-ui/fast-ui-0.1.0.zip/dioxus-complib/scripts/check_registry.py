#!/usr/bin/env python3
"""Install real registry components into an independent, temporary Rust app.

No source files in a consumer project are overwritten. The dx executable must
be version 0.7.10-compatible. Cargo dependencies must be available offline.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def run(args, cwd, **kwargs):
    return subprocess.run(args, cwd=cwd, check=True, text=True, **kwargs)


with tempfile.TemporaryDirectory(prefix="fast-ui-consumer-") as directory:
    consumer = Path(directory)
    (consumer / "src").mkdir()
    manifest = '''[package]
name = "fast-ui-independent-consumer"
version = "0.1.0"
edition = "2021"
[workspace]
[dependencies]
dioxus = { version = "0.7.10", features = ["web"] }
'''
    (consumer / "Cargo.toml").write_text(manifest)
    (consumer / "src/main.rs").write_text("fn main() {}\n")
    env = dict(os.environ, CARGO_NET_OFFLINE="true")
    env.setdefault("CARGO_TARGET_DIR", str(ROOT / "target"))
    command = ["dx", "components", "add", "theme", "button", "field", "table", "dialog",
               "--path", str(ROOT), "--module-path", "src/ui", "--offline"]
    run(command, consumer, env=env)
    assert (consumer / "Cargo.toml").read_text() == manifest, "Installer changed host dependencies"

    hashes = {}
    for source in (ROOT / "registry").glob("*/*"):
        if source.name == "component.json":
            continue
        installed = consumer / "src/ui" / source.parent.name / source.name
        assert installed.read_bytes() == source.read_bytes(), f"Copy differs: {installed}"
        hashes[str(installed.relative_to(consumer))] = hashlib.sha256(installed.read_bytes()).hexdigest()
    (consumer / "fast-ui.lock.json").write_text(json.dumps({"framework": "0.7.10", "files": hashes}, indent=2))

    # Existing, locally customized components must never be silently replaced.
    button = consumer / "src/ui/button/mod.rs"
    button.write_text(button.read_text() + "\n// consumer-owned customization\n")
    result = subprocess.run(command, cwd=consumer, env=env, text=True, capture_output=True)
    assert result.returncode != 0, "Reinstall should require conflict resolution"
    assert button.read_text().endswith("// consumer-owned customization\n")

    (consumer / "src/main.rs").write_text('''
mod ui;
use dioxus::prelude::*;
use ui::{button::Button, dialog::Dialog, field::{Field, Input}, table::Table, theme::{Theme, ThemeStyles}};
fn main() { dioxus::launch(App); }
#[component]
fn App() -> Element {
    let mut query = use_signal(String::new);
    let mut open = use_signal(|| false);
    rsx! {
        ThemeStyles {}
        Theme {
            Field { id: "inventory-search", label: "Find equipment",
                Input { value: query(), on_value_change: move |value| query.set(value), name: "query" }
            }
            Table { caption: "Equipment", tbody { tr { td { "Camera" } } } }
            Button { onclick: move |_| open.set(true), "Reserve" }
            Dialog { id: "reserve", title: "Reserve equipment", open: open(), on_open_change: move |value| open.set(value),
                Button { onclick: move |_| open.set(false), "Cancel" }
            }
        }
    }
}
''')
    run(["cargo", "check", "--offline", "--target", "wasm32-unknown-unknown"], consumer, env=env)
    print("PASS: clean registry install, unchanged host dependencies, exact source/assets, local-edit protection, independent WASM consumer.")

