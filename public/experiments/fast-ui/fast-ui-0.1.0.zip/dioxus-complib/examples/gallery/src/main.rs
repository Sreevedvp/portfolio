use dioxus::prelude::*;
use fast_ui::*;

fn main() {
    dioxus::launch(App);
}

#[component]
fn App() -> Element {
    let mut name = use_signal(|| "Studio workspace".to_string());
    let mut email = use_signal(String::new);
    let mut validate = use_signal(|| false);
    let mut open = use_signal(|| false);
    let mut nested = use_signal(|| false);
    let mut dismissible = use_signal(|| true);
    let mut submitted = use_signal(|| 0);
    let mut compact = use_signal(|| false);
    let mut alternate = use_signal(|| false);
    let error = use_memo(move || {
        (validate() && !email().contains('@'))
            .then(|| "Enter an email address with an @ sign.".to_string())
    });
    rsx! {
        ThemeStyles {}
        document::Style { {include_str!("gallery.css")} }
        Theme { compact: compact(), class: if alternate() { "gallery alternate" } else { "gallery" },
            header { class: "gallery-header",
                a { href: "#top", class: "gallery-brand", "f / ui" }
                span { "COMPONENTS FOR RUST" }
                span { class: "gallery-version", "0.1 · DIOXUS 0.7" }
            }
            main { id: "top",
                section { class: "gallery-intro",
                    p { class: "overline", "THE FASTMEDIUM COLLECTION" }
                    h1 { "Small pieces." br {} em { "Your next interface." } }
                    p { class: "gallery-deck", "Composable Rust components. A warm palette, precise borders, and room to make them your own." }
                    div { class: "gallery-actions",
                        Button { onclick: move |_| open.set(true), "Try a dialog ↗" }
                        Button { variant: ButtonVariant::Secondary, onclick: move |_| compact.toggle(),
                            if compact() { "Comfortable spacing" } else { "Compact spacing" }
                        }
                        Button { variant: ButtonVariant::Ghost, onclick: move |_| alternate.toggle(), "Switch theme" }
                    }
                }
                section { class: "gallery-section", id: "buttons",
                    div { class: "section-label", span { "01 / ACTIONS" } h2 { "A clear next step." } }
                    div { class: "sample-grid",
                        article { class: "sample-panel",
                            h3 { "Button variants" }
                            div { class: "gallery-actions",
                                Button { "Primary" }
                                Button { variant: ButtonVariant::Secondary, "Secondary" }
                                Button { variant: ButtonVariant::Ghost, "Ghost" }
                                Button { variant: ButtonVariant::Destructive, "Destructive" }
                            }
                        }
                        article { class: "sample-panel",
                            h3 { "Sizes & states" }
                            div { class: "gallery-actions",
                                Button { size: ButtonSize::Small, "Small" }
                                Button { size: ButtonSize::Large, "Large" }
                                Button { disabled: true, "Disabled" }
                                Button { loading: true, "Saving…" }
                            }
                        }
                    }
                }
                section { class: "gallery-section", id: "forms",
                    div { class: "section-label", span { "02 / FIELDS" } h2 { "Everything in its place." } }
                    div { class: "sample-grid",
                        form { class: "sample-panel form-stack",
                            onsubmit: move |event| { event.prevent_default(); validate.set(true); if email().contains('@') { submitted += 1; } },
                            Field { id: "workspace-name", label: "Workspace name", hint: "A name your team will recognize.",
                                Input { value: name(), on_value_change: move |value| name.set(value), name: "workspace", required: true }
                            }
                            Field { id: "contact-email", label: "Contact email", error: error(),
                                Input { value: email(), on_value_change: move |value| email.set(value), placeholder: "you@example.com", name: "email" }
                            }
                            Button { button_type: ButtonType::Submit, "Save workspace" }
                            p { role: "status", class: "sample-note", "Saved {submitted} times. All data stays in this example." }
                        }
                        article { class: "sample-panel form-stack",
                            h3 { "Native behavior. Clear context." }
                            Field { id: "readonly-field", label: "Read-only", hint: "Labels and descriptions are connected automatically.",
                                Input { value: "Read-only value", on_value_change: |_| {}, readonly: true }
                            }
                            Field { id: "disabled-field", label: "Disabled",
                                Input { value: "Unavailable", on_value_change: |_| {}, disabled: true }
                            }
                            p { class: "sample-note", "Bring your validation, data, and application state. The component handles the presentation." }
                        }
                    }
                }
                section { class: "gallery-section", id: "tables",
                    div { class: "section-label", span { "03 / TABLES" } h2 { "Structure without the clutter." } }
                    Table { caption: "Studio equipment",
                        thead { tr { th { scope: "col", "Item" } th { scope: "col", "Category" } th { scope: "col", "Availability" } th { scope: "col", "Action" } } }
                        tbody {
                            for (item, category, status) in [("Field recorder", "Audio", "Available"), ("Studio monitor", "Display", "In use"), ("Travel tripod", "Photography", "Available")] {
                                tr { key: "{item}",
                                    td { "{item}" } td { "{category}" } td { span { class: "status-label", "{status}" } }
                                    td { Button { size: ButtonSize::Small, variant: ButtonVariant::Ghost, onclick: move |_| open.set(true), "Details ↗" } }
                                }
                            }
                        }
                    }
                }
                section { class: "gallery-section overlay-preview",
                    div { class: "section-label", span { "04 / DIALOGS" } h2 { "A little room to focus." } }
                    p { "Native modal behavior with controlled state, keyboard dismissal, and focus restoration." }
                    Button { onclick: move |_| open.set(true), "Open example" }
                }
                footer { "FAST UI / Built from FastMedium. Ready for your application." }
            }
            Dialog { id: "gallery-dialog", open: open(), on_open_change: move |value| open.set(value),
                title: "Make room for your ideas", description: "A generic dialog with any content you need. Escape or Close returns you to the trigger.",
                dismissible: dismissible(), close_on_backdrop: true,
                div { class: "form-stack",
                    Field { id: "dialog-name", label: "Workspace name",
                        Input { value: name(), on_value_change: move |value| name.set(value) }
                    }
                    label { class: "sample-note", input { r#type: "checkbox", checked: !dismissible(), onchange: move |e| dismissible.set(!e.checked()) } " Prevent dismissal (pending action demo)" }
                    div { class: "gallery-actions",
                        Button { variant: ButtonVariant::Secondary, onclick: move |_| nested.set(true), "Nested dialog" }
                        Button { disabled: !dismissible(), onclick: move |_| open.set(false), "Done" }
                    }
                }
                Dialog { id: "nested-dialog", open: nested(), on_open_change: move |value| nested.set(value),
                    title: "One more detail", description: "Escape closes only this dialog. Focus returns to the parent.",
                    Button { onclick: move |_| nested.set(false), "Return" }
                }
            }
        }
    }
}
