use dioxus::prelude::*;
use fast_ui::*;

fn main() {
    dioxus::launch(App);
}

#[component]
fn App() -> Element {
    let mut component = use_signal(|| "Buttons");
    let mut sage = use_signal(|| false);
    let mut name = use_signal(|| "My next project".to_string());
    let mut email = use_signal(String::new);
    let mut validate = use_signal(|| false);
    let mut open = use_signal(|| false);
    let mut message = use_signal(|| "Ready when you are.".to_string());
    let error = use_memo(move || {
        (validate() && !email().contains('@'))
            .then(|| "Please enter a valid email address.".to_string())
    });
    rsx! {
        ThemeStyles {}
        document::Style { {include_str!("playground.css")} }
        Theme { class: if sage() { "playground sage" } else { "playground" },
            div { class: "playground-toolbar",
                span { "LIVE / RUST + DIOXUS" }
                button { class: "theme-toggle", r#type: "button", onclick: move |_| sage.toggle(),
                    "aria-pressed": sage().to_string(), if sage() { "◉ Sage" } else { "◉ Blush" }
                }
            }
            nav { class: "component-picker", "aria-label": "Choose a component",
                for label in ["Buttons", "Fields", "Table", "Dialog"] {
                    button { r#type: "button", "aria-pressed": (component() == label).to_string(),
                        onclick: move |_| { component.set(label); message.set("Ready when you are.".to_string()); }, "{label}"
                    }
                }
            }
            main { class: "preview-stage",
                match component() {
                    "Buttons" => rsx! {
                        p { class: "preview-eyebrow", "01 / A CLEAR NEXT STEP" }
                        h1 { "Make something happen." }
                        p { class: "preview-description", "Four variants. Native button behavior. Your application owns the action." }
                        div { class: "button-row",
                            Button { onclick: move |_| message.set("Primary action clicked.".to_string()), "Create project ↗" }
                            Button { variant: ButtonVariant::Secondary, onclick: move |_| message.set("Secondary action clicked.".to_string()), "Save for later" }
                        }
                        div { class: "button-row",
                            Button { variant: ButtonVariant::Ghost, onclick: move |_| message.set("Ghost action clicked.".to_string()), "A quieter action" }
                            Button { variant: ButtonVariant::Destructive, onclick: move |_| open.set(true), "Remove item" }
                        }
                        div { class: "button-row states-row", Button { size: ButtonSize::Small, disabled: true, "Disabled" } Button { size: ButtonSize::Small, loading: true, "Saving…" } }
                    },
                    "Fields" => rsx! {
                        p { class: "preview-eyebrow", "02 / A LITTLE CONTEXT" }
                        h1 { "Give your idea a name." }
                        form { class: "preview-form", onsubmit: move |e| { e.prevent_default(); validate.set(true); if email().contains('@') { message.set("Saved locally in this demo.".to_string()); } },
                            Field { id: "demo-project", label: "Project name", hint: "Labels and descriptions are connected for you.",
                                Input { value: name(), on_value_change: move |value| name.set(value), required: true }
                            }
                            Field { id: "demo-email", label: "Email", error: error(),
                                Input { value: email(), on_value_change: move |value| email.set(value), placeholder: "you@example.com" }
                            }
                            Button { button_type: ButtonType::Submit, "Save project" }
                        }
                    },
                    "Table" => rsx! {
                        p { class: "preview-eyebrow", "03 / ROOM FOR YOUR DATA" }
                        h1 { "A little more structure." }
                        Table { caption: "Project workspace",
                            thead { tr { th { scope: "col", "Project" } th { scope: "col", "Status" } th { scope: "col", "Action" } } }
                            tbody {
                                for (project, status) in [("Personal notes", "In progress"), ("Component lab", "Experimental"), ("Reading list", "Ready")] {
                                    tr { key: "{project}", td { "{project}" } td { "{status}" }
                                        td { Button { size: ButtonSize::Small, variant: ButtonVariant::Ghost, onclick: move |_| message.set(format!("Selected {project}.")), "View ↗" } }
                                    }
                                }
                            }
                        }
                    },
                    _ => rsx! {
                        p { class: "preview-eyebrow", "04 / A MOMENT TO FOCUS" }
                        h1 { "One decision at a time." }
                        p { class: "preview-description", "A controlled modal with keyboard support, an inert background, and focus restoration." }
                        Button { onclick: move |_| open.set(true), "Open dialog ↗" }
                        p { class: "keyboard-note", kbd { "Esc" } " to close · " kbd { "Tab" } " to move between controls" }
                    },
                }
            }
            footer { role: "status", span { class: "status-dot", "aria-hidden": "true" } "{message}" }
            Dialog { id: "playground-dialog", title: "Ready for a fresh start?", description: "This is a live component example. Confirming only updates this preview.",
                open: open(), on_open_change: move |value| open.set(value), close_on_backdrop: true,
                div { class: "button-row",
                    Button { variant: ButtonVariant::Secondary, onclick: move |_| open.set(false), "Keep exploring" }
                    Button { onclick: move |_| { message.set("Confirmed. Nothing outside this demo changed.".to_string()); open.set(false); }, "Confirm action" }
                }
            }
        }
    }
}
