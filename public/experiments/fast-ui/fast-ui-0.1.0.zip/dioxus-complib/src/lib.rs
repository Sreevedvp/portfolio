//! Small, composable UI components. Mount [`ThemeStyles`] once and wrap your UI
//! in [`Theme`]. The registry files are also the crate's source of truth.
#[path = "../registry/button/mod.rs"]
pub mod button;
#[path = "../registry/dialog/mod.rs"]
pub mod dialog;
#[path = "../registry/field/mod.rs"]
pub mod field;
#[path = "../registry/table/mod.rs"]
pub mod table;
#[path = "../registry/theme/mod.rs"]
pub mod theme;

pub use button::*;
pub use dialog::*;
pub use field::*;
pub use table::*;
pub use theme::*;
